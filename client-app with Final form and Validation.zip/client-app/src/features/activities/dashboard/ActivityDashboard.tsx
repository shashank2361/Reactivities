import React, { useContext, useEffect } from 'react';
import { Grid } from 'semantic-ui-react';
import  ActivityList  from './ActivityList';
import ActivityStore from '../../../app/stores/activityStore';


import {observer} from 'mobx-react-lite';
import { LoadingComponents } from '../../../app/layout/LoadingComponents';

const ActivityDashboard :React.FC= () => {
 
     
    const activityStore =  useContext(ActivityStore)
   
    useEffect( () => {
     activityStore.loadActivities();
   },[activityStore])
  
   if   (activityStore.loadingInitial ) return <LoadingComponents  content = 'Loading Activity ...' />
   
 
        return (
        <Grid>
            <Grid.Column width={10}>
           <ActivityList/>
            </Grid.Column>         
             <Grid.Column width={6}>
            </Grid.Column>
        
        </Grid>
         
    )
}


export default observer (ActivityDashboard);


//         {activity &&  !editMode  &&  
            //               <ActivityDetails/>
            //         }            
            //         { editMode &&   <ActivityForm key={activity && ( activity.id || 0 )} 
            //               activity = {activity!} 

            //              /> }

  