import React ,{ useEffect ,Fragment,  useContext} from 'react';
import {  Container } from 'semantic-ui-react'
 import  NavBar  from '../../fearures/nav/NavBar';
import ActivityDashboard from '../../fearures/activities/dashboard/ActivityDashboard';
import { LoadingComponents } from './LoadingComponents';
import ActivityStore from '../stores/activityStore'
 

const App = () =>   {

  const activityStore =  useContext(ActivityStore)

   
   
useEffect( () => {
   activityStore.loadActivities();
 },[activityStore])

 if   (activityStore.loadingInitial ) return <LoadingComponents  content = 'Loading Activity ...' />
  return (
    <Fragment>
    <NavBar />
      <Container style ={{marginTop :'9em'}}>
    <ActivityDashboard 
         />
    
    </Container>  
    
    </Fragment>
  );
 
}

export default  App;

// app is observing the observable